// Função para alternar entre temas
function toggleTheme() {
    const body = document.body;

    // Verifica se o tema atual é dark ou light
    if (body.classList.contains('dark-theme')) {
        // Se for dark, muda para light
        body.classList.remove('dark-theme');
    } else {
        // Se for light, muda para dark
        body.classList.add('dark-theme');
    }
}

// Adicione um ouvinte de eventos ao botão de alternância de tema
const themeToggleBtn = document.getElementById('theme-toggle');
themeToggleBtn.addEventListener('click', toggleTheme);
function toggleTheme() {
    const body = document.body;

    // Verifica se o tema atual é "dark"
    if (body.classList.contains("dark-theme")) {
        // Se for "dark", muda para "light"
        body.classList.remove("dark-theme");
    } else {
        // Se for "light", muda para "dark"
        body.classList.add("dark-theme");
    }
}